WITH yearly_revenue AS (
    SELECT
        `Product Category` AS ProductCategory,
        YEAR(OrderDate) AS Yr,
        SUM(`Order Quantity` * `Sale Price`) AS TotalRevenue
    FROM orders
    GROUP BY `Product Category`, YEAR(OrderDate)
),
latest_year AS (
    SELECT MAX(Yr) AS LatestYear
    FROM yearly_revenue
),
comparison AS (
    SELECT
        y.ProductCategory,
        y.Yr AS CurrentYear,
        y.TotalRevenue AS CurrentYearRevenue,
        p.TotalRevenue AS PreviousYearRevenue,
        (y.TotalRevenue - COALESCE(p.TotalRevenue, 0)) AS RevenueIncrease
    FROM yearly_revenue y
    JOIN latest_year ly
        ON y.Yr = ly.LatestYear
    LEFT JOIN yearly_revenue p
        ON p.ProductCategory = y.ProductCategory
       AND p.Yr = y.Yr - 1
)
SELECT
    ProductCategory,
    PreviousYearRevenue,
    CurrentYearRevenue,
    RevenueIncrease
FROM comparison
ORDER BY RevenueIncrease DESC
LIMIT 3;
