SELECT 
    Location AS Region,
    COUNT(*) AS TotalOrders,
    AVG(`Sale Price`) AS AvgSalePrice
FROM orders
GROUP BY Location
HAVING COUNT(*) > 150
ORDER BY AvgSalePrice DESC
LIMIT 3;
