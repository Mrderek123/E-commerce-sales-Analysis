UPDATE orders o
JOIN (
    SELECT CustomerID
    FROM orders
    GROUP BY CustomerID
    HAVING COUNT(*) >= 10
) c ON o.CustomerID = c.CustomerID
SET o.`Sale Price` = o.`Sale Price` * 0.85;
SELECT CustomerID, `Sale Price`
FROM orders
WHERE CustomerID IN (
    SELECT CustomerID
    FROM orders
    GROUP BY CustomerID
    HAVING COUNT(*) >= 10
)
LIMIT 20;

SELECT CustomerID, COUNT(*) AS OrderCount
FROM orders
GROUP BY CustomerID
ORDER BY OrderCount DESC
LIMIT 100;


UPDATE orders o
JOIN (
    SELECT CustomerID
    FROM orders
    GROUP BY CustomerID
    HAVING SUM(`Order Quantity`) >= 10
) c ON o.CustomerID = c.CustomerID
SET o.`Sale Price` = o.`Sale Price` * 0.85;

SELECT 
    CustomerID,
    `Sale Price`,
    `Order Quantity`
FROM orders
WHERE CustomerID IN (
    SELECT CustomerID
    FROM orders
    GROUP BY CustomerID
    HAVING SUM(`Order Quantity`) >= 10
)
LIMIT 20;


