WITH monthly_revenue AS (
    SELECT 
        DATE_FORMAT(OrderDate, '%Y-%m') AS Month,
        SUM(`Order Quantity` * `Sale Price`) AS TotalRevenue
    FROM orders
    GROUP BY DATE_FORMAT(OrderDate, '%Y-%m')
),
growth_calc AS (
    SELECT
        Month,
        TotalRevenue,
        LAG(TotalRevenue) OVER (ORDER BY Month) AS PrevRevenue,
        ((TotalRevenue - LAG(TotalRevenue) OVER (ORDER BY Month)) /
         LAG(TotalRevenue) OVER (ORDER BY Month)) * 100 AS GrowthRate
    FROM monthly_revenue
)
SELECT 
    Month,
    TotalRevenue,
    COALESCE(GrowthRate, 0) AS GrowthRate
FROM growth_calc
ORDER BY Month;

