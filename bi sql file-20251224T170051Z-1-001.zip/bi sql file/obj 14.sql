WITH customer_stats AS (
    SELECT 
        CustomerID,
        SUM(`Order Quantity` * `Sale Price`) AS TotalRevenue,
        COUNT(*) AS OrderFrequency,
        AVG(`Order Quantity` * `Sale Price`) AS AvgOrderValue
    FROM orders
    GROUP BY CustomerID
),
score_calc AS (
    SELECT
        CustomerID,
        TotalRevenue,
        OrderFrequency,
        AvgOrderValue,
        (0.5 * TotalRevenue) +
        (0.3 * OrderFrequency) +
        (0.2 * AvgOrderValue) AS CompositeScore
    FROM customer_stats
)
SELECT 
    CustomerID,
    TotalRevenue,
    OrderFrequency,
    AvgOrderValue,
    CompositeScore
FROM score_calc
ORDER BY CompositeScore DESC
LIMIT 5;
