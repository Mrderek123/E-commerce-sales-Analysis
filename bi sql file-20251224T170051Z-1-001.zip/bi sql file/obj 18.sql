WITH ordered_data AS (
    SELECT 
        CustomerID,
        OrderDate,
        LAG(OrderDate) OVER (
            PARTITION BY CustomerID 
            ORDER BY OrderDate
        ) AS PrevOrderDate
    FROM orders
),
day_diff AS (
    SELECT
        CustomerID,
        DATEDIFF(OrderDate, PrevOrderDate) AS DaysBetween
    FROM ordered_data
    WHERE PrevOrderDate IS NOT NULL
),
eligible_customers AS (
    SELECT 
        CustomerID
    FROM orders
    GROUP BY CustomerID
    HAVING COUNT(*) >= 5    -- customers with at least 5 separate orders
)
SELECT
    d.CustomerID,
    AVG(d.DaysBetween) AS AvgDaysBetweenOrders
FROM day_diff d
JOIN eligible_customers e 
      ON d.CustomerID = e.CustomerID
GROUP BY d.CustomerID
ORDER BY AvgDaysBetweenOrders;


