WITH MonthlyRevenue AS (
    SELECT
        COALESCE(NULLIF(`Product Category`, ''), 'No Category Provided') AS ProductCategory,
        DATE_FORMAT(OrderDate, '%Y-%m') AS Month,
        SUM(`Sale Price` * `Order Quantity`) AS TotalRevenue
    FROM orders
    GROUP BY 
        COALESCE(NULLIF(`Product Category`, ''), 'No Category Provided'),
        DATE_FORMAT(OrderDate, '%Y-%m')
)

SELECT
    ProductCategory,
    Month,
    TotalRevenue,
    ROUND(
        AVG(TotalRevenue) OVER (
            PARTITION BY ProductCategory
            ORDER BY Month
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 2
    ) AS Rolling3MonthAvgRevenue
FROM MonthlyRevenue
ORDER BY ProductCategory, Month;


